package com.cg.sts.exception;

public class STSException  extends Exception{

		public STSException()
		{
			super();
		}
		public STSException(String args)
		{
			super(args);
		}
}

