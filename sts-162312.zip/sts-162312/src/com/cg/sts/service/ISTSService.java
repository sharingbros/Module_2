package com.cg.sts.service;

import java.util.List;

import com.cg.sts.entity.STSEntity;

public interface ISTSService {
	
	List<STSEntity> retrieve();
	
}
