package com.cg.sts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sts.dao.ISTSDAO;
import com.cg.sts.entity.STSEntity;
@Service
public class STSServiceImp implements ISTSService {

	@Autowired
	ISTSDAO dao;
	
	@Override
	public List<STSEntity> retrieve() {
		// TODO Auto-generated method stub
		return dao.retrieve();
	}

}
