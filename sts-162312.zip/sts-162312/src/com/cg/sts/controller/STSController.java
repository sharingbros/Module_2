package com.cg.sts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.sts.entity.STSEntity;
import com.cg.sts.exception.STSException;
import com.cg.sts.service.ISTSService;

@Controller
public class STSController 
{
	@Autowired
	ISTSService service;
	List<STSEntity> bean=null;
	STSEntity orderBean=new STSEntity();
	ModelAndView model=null;
	@RequestMapping(value="all")
	public ModelAndView home()
	{
		bean=service.retrieve();
		return new ModelAndView("home","data",bean);
	}	
	
	@RequestMapping(value="orderpage")
	public ModelAndView orderpage(@RequestParam("name") String name)
	{
		for (STSEntity stsEntity : bean) {
			if(stsEntity.getCompanyName().equals(name))
				orderBean=stsEntity;
		}
		return new ModelAndView("orderpage","order",orderBean);
	}
	
	@RequestMapping(value="success")
	public ModelAndView success(@RequestParam("quantity") String quantityString) throws STSException
	{
		double quantity=Double.parseDouble(quantityString);
		if(quantity>0)
		{
			model= new ModelAndView("success");		
			double totalCost=quantity*orderBean.getQuote();
			model.addObject("companyname", orderBean.getCompanyName());
			model.addObject("cost", totalCost);
			return model;
		}
		else
		{
			throw new STSException("enter correct quantity in numbers");
		}
	}
}
