package com.cg.sts.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.sts.entity.STSEntity;
@Repository
public class STSDAOImp implements ISTSDAO {

	@PersistenceContext
	EntityManager em;
	
	@Override
	public List<STSEntity> retrieve() {
		// TODO Auto-generated method stub
		
		List<STSEntity> bean=null;
		
		Query str=em.createQuery("from STSEntity");
		bean=str.getResultList();
		return bean;
	}

}
