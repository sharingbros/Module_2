package com.cg.sts.dao;

import java.util.List;

import com.cg.sts.entity.STSEntity;

public interface ISTSDAO {
	List<STSEntity> retrieve();
}
