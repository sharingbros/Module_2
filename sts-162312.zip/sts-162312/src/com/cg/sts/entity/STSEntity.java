package com.cg.sts.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class STSEntity {

	@Id
	@GeneratedValue
	private int compantyId;
	@Column(name="companyName")
	private String companyName;
	@Column(name="quote")
	private  double quote;
	
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public double getQuote() {
		return quote;
	}
	public void setQuote(double quote) {
		this.quote = quote;
	}
	public STSEntity(String companyName, double quote) {
		super();
		this.companyName = companyName;
		this.quote = quote;
	}
	@Override
	public String toString() {
		return "STSEntity [compantyId=" + compantyId + ", companyName="
				+ companyName + ", quote=" + quote + "]";
	}
	public STSEntity() {
		super();
	}
	
}
