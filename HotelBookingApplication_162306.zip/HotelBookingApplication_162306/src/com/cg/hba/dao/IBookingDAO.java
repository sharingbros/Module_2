package com.cg.hba.dao;

import java.util.List;

import com.cg.hba.dto.HotelDetails;

public interface IBookingDAO {

	List<HotelDetails> showAllHotels();

	
}
