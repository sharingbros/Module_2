package com.cg.hba.service;

import java.util.List;

import com.cg.hba.dto.HotelDetails;

public interface IBookingService {

	List<HotelDetails> showAllHotels();

}
